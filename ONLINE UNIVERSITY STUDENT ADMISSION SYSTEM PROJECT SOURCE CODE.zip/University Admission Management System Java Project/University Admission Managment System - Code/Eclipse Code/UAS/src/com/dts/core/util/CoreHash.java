package com.dts.core.util;

import java.util.Hashtable;

public class CoreHash extends Hashtable
{

}
