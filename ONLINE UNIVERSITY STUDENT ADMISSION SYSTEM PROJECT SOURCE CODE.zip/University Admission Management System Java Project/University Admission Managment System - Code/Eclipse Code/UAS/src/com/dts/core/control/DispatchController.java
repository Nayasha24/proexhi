package com.dts.core.control;

import javax.servlet.http.HttpServlet;

public class DispatchController extends HttpServlet
{

}
